import {Component} from '@angular/core'
@Component(
    {
        selector : 'financecomp',
        template : `<h5>This is finance news</h5>
        <a routerLink="/news/financenews/equitynews">EquityNews</a>
        `
    }
)
export class FinanceNewsComponent {
    
}