import {Component} from '@angular/core'
@Component(
    {
        selector: 'sportscomp',
        template: `<h5>This is the area for Sports News</h5>`
    }
)
export class SportNewsComponent {

}