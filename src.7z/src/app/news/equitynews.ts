import {Component} from '@angular/core'
@Component({
    selector : "equitycomp",
    template : `<h5>This is equity news</h5>`
})
export class EquityNewsComponent{
    
}