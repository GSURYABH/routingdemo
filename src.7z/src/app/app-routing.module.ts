import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AboutComponent} from './about/about.component';
import {NewsComponent} from './news/news.component';
import { SportNewsComponent } from './news/sportnews';
import { EquityNewsComponent } from './news/equitynews';
import { FinanceNewsComponent } from './news/financenews';

const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot([
    {path:'about', component :AboutComponent},
    {path:'news', component :NewsComponent,
    children : [
      {path:'sports',component :SportNewsComponent},
      {path:'finance', component : FinanceNewsComponent},
      {path:'equity',component:EquityNewsComponent}
    ]}
  ])],
  exports: [RouterModule]
})
export class AppRoutingModule { }
